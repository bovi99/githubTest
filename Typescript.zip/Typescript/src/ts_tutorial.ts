//import from typescript.ts file and call it
import typescript from "./typescript";
typescript();

//BASIC TYPES/VARIABLES
//we can use let and const for creating variables

//let-we can reassign a value
let techcoder : string = 'Tech Coder'
//assign the value to let
techcoder = 'ABCD'
//const-we cant reassign a value
const techcoder1 :string='Tech Coder'



//export function from ts_tutorial.ts
export default function(){
    //BOOLEAN
    //create a CONST VARIBLE for boolean type and assign value as true
    const _boolean : boolean =true;
    //print value of _boolean type,typeof method used for indicate type of one
    console.log(typeof(_boolean));
    
    //NUMBER
    //create a CONST VARIBLE for number type and assign value as 9
    //we can assign the octal,decimal,binary,float,double,int as this number,but in js and ts we have only number type for all one
    const _number: number = 30;
   

    //print value of _number type,typeof method used for indicate type of one
    console.log(typeof(_number));

    //create a CONST VARIBLE for string type and assign value as cey spice,_string is varible name ,string is type
    const  _string : string = "Cey Spice";
    //print value of _boolean type,typeof method used for indicate type of one
    console.log(typeof(_string));

    //ARRAY
    //create array called array1 ,<number> indicates array includes numbers,generate interface is Array ,number is type
    const array1 : Array<number> = [5,5];
    //print value of array as 5 or 5
    console.log(typeof(array1));
    //number array -array2
    const array2 : number[] = [6,6];
    console.log(typeof(array2));
    //create another array called array2
    const array3 : Array<string>= ['thu','rui','weo'];
    console.log(typeof(array3));

    //TUPLE -craete tupel ,that can be stored multiple types of data ,text,number,boolean
    const _tuple : [string,number,boolean] = ['thushi',1999,false];
    console.log (typeof(_tuple));

    //ENUM-this is the type that includes no of colors ,Color is enum name ,we cna only assign colors of enum ,color is constant
    //enum has number its started at 0 to...,the green is 0 value of this enum
    enum Color{
        GREEN=0,
        YELLOW=1,
        RED=2,
    }
    //const name is color ,and Color is enum name,and type and it assign to Color.GREEN or RED or YELLOW
    const color : Color = Color.GREEN;
    //print color name
    console.log(typeof(color));
    const color1 : Color = Color.RED;
    const color2 : Color = Color.YELLOW;

    //NULL is no value to assign
    const _null :null = null;
    console.log(typeof(_null));

    //UNDEFINED this can be assign to only undefined no values
    const _undefined : undefined = undefined;
    console.log(typeof(_undefined));

    //OBJECT -that dispaly inside the {},we should put inside that and assign that values,we cant assign null in typescript,null is not a object type in TS
    const _object : object = {};
    console.log(typeof(_object));

    //ANY-this can be any values(null,obj,enum,string,numbers,undefined)
    const _any : any = [1,'string',undefined,Color.YELLOW];
    console.log(typeof(_any));

    //in typescrpt the array,any,null is called object not array,we type "typeof" display as object
}
//in typescript we can use withot return value ,only keep place void ,but javascript canot do this,return only void its undefined value
//function printName(name:string): void {
                   //or
//const printName = function (name:string): void {
//console.log(name);
//}

//ARROW FUNCTION () =>{}
const printName2 = (name:string):void => {
    console.log(name);
}
//CLASS
class Dog {
    static className = 'Dog'
    name:string
    //set parameters
    constructor(name:string){
     this.name = name;
    }

    static PrintClassName(){
        console.log(Dog.className);
    }
    
    printName(){
        console.log(this.name);
    }
}

//printName('bovini')

    const d =new Dog('Leo');
    d.printName()
    Dog.PrintClassName();

//INTERFACE
    interface A {
    name:string;
    //create method of interface
    printName(name:string):void;
    }
    //properties of interface A is included in to class B
class B implements A{
    //we can create varibles and methods as properties
name: string= '';
//implement the method without parameter[name],but its not issue in type script,bcz already work this method without parameter
printName(): string {
    //we canot use name:string inside class b method parameter bcz not defined in this interface
    console.log(this.name);
    return '';
}
//method signature-name of method [printName]and parameters of method[name]
}
//type safety is included in typescript,js has not type safety,till compile the code ,work typescript after compilied ,works js
class Fox {
    makeSound():void{
        console.log("hoo hoo");
    }
   
}

class Cat {
    makeSound():void{
        console.log("mew mew");
    }
}
//varible Dog assign to object Cat bcz method signature of these two classes are equal.
const animal1:Fox = new Cat();

interface Animal{
    makeSound():void;
}

 class Horse implements Animal{
    makeSound():void{
        console.log("hoo hoo");
    }
     //create a function/method as tail
    tail():void{
        console.log('tail');
    }
   
}

class Elephant implements Animal{
    makeSound():void{
        console.log("mew mew");
    }
}
//varible Dog assign to object Cat bcz method signature of these two classes are equal.
//let can use same varble name for many types ,const cant
let animal2 : Animal = new Elephant();
animal2.makeSound();
animal2 = new Horse();
animal1.makeSound();


//union types
"use strict";
function kgToLbs(weight ) {

    if (typeof weight === 'number')  {
       return weight * 2.2;
    
    else 
        return parseInt(weight) * 2.2;
    }

}

kgToLbs(10);
kgToLbs('10kg');
 
//intersection types
let weight: number & string;

type Draggable  = {
drag: () => void

};

type Resizable = {
    resize: () => void
};

type UIWidget = Draggable & Resizable;

let textBox: UIWidget = {
    drag: () => {},
    resize: () => {}

}
//Literal (exact,specific)
type Quantity = 50| 100;
let quantity : Quantity =100;

type Metric = 'cm' | 'inch';

//Nullable Types
function greet(name: string | null | undefined) {
    if(name)
    console.log(name.toUpperCase());
    else
    console.log('Hola');
}

greet(undefined);

//Optional Changing
type Customer = {
    birthday: Date
};

function getCustomer(id: number): Customer | null {
    return id === 0 ? null : birthday: new Date() };

let customer = getCustomer(0);
    //optional property access oprator
console.log(customer?.birthday?.getFullYear());

let log: any = null;
log?.('a');



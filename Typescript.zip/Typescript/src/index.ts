export type Name = {name: string};
export type Age = {age: number};

//contain properties of name or age 
type Union = Name | Age;

//contain both properties of name & age
type Intersection = Name & Age;

const name = { name:'Jane'};
const age = {age: 29};
const nameAndAge = {name: 'Jane', age:29};
const nameOrAge = {name: 'Jane', age:29};

let union: Union;
let intersection:Intersection;

union=nameOrAge;
intersection=nameAndAge;

function filter(union: Union){
    if ('name' in union) { //check name
        union.name;
    }

    if('age' in union) { //check age
        union.age;
    }
    
    if('name' in intersection || 'age' in intersection){ // we cant check these using union(&&) bcz we  can check only one at one time
        intersection.name;
        intersection.age;
    }
}

enum LoginMode {
    app =2,
    email=0,
    social=1,
}
console.log(LoginMode.email);//0
console.log(LoginMode.social);//1

function intiateLogin(mode: LoginMode) {
    // ....
}

intiateLogin(LoginMode.app);
intiateLogin(LoginMode.email);
intiateLogin(LoginMode.social);

intiateLogin(0);
intiateLogin(1);

//Lookup and reverse lookup
console.log(LoginMode['app']); //0
console.log(LoginMode[0]); // 'app'

//get all the keys
const keys = Object.keys(LoginMode);

console.log (keys);
//Want: ['app','email','social']
//Got: ['app','email','social','0','1','2']

type LoginMode1=
'app'
'email'
'social';

function intiaintiateLogin1(loginMode1: LoginMode1) {

}
 intiateLogin(0);

 //create object
 export const LoginMode2 = {
    device: 'devicee',
    email:'email',
    social:'social',
 }as const;
 
 export type LoginMode2=keyof typeof LoginMode2 ;

 export function intiaintiateLogin2(mode:LoginMode2){

 }


